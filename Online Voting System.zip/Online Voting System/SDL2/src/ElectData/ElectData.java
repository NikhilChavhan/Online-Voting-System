package ElectData;

public class ElectData {
    public String Election_Name;
    public int Candidate_Count;
    public  String date;
    public String Start_Time;
    public String End_Time;
}
